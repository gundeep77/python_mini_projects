Use the following format for entering links:

<link copied from youtube><single space><file-type(enter audio or video)>

Enter in this format only.

All done!!
Enjoy!!